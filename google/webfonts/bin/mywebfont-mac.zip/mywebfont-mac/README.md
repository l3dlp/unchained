# mywebfont

CLI Go minimaliste qui scanne une arborescence `webfonts/<Famille>/*.ttf` et genere une GUI statique pour copier le CSS `@font-face`.

```sh
go run ./cmd/mywebfont -root /chemin/vers/webfonts -out webfonts.html -base-url webfonts
```

Pose `webfonts.html` a cote du dossier `webfonts`, ouvre-le, cherche une fonte, coche les variantes, puis copie le bloc voulu.
